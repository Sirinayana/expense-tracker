import { ArrowDownLeft, ArrowUpRight, Trash2 } from 'lucide-react';

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(value);
}

function formatDate(value) {
  if (!value) return '';
  return new Date(`${value}T00:00:00`).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default function TransactionList({ transactions, onDelete, filter, onFilterChange }) {
  return (
    <section className="panel transactions-panel">
      <div className="section-heading transaction-heading">
        <div><p className="eyebrow">ACTIVITY</p><h2>Recent transactions</h2></div>
        <select aria-label="Filter transactions" value={filter} onChange={(e) => onFilterChange(e.target.value)}>
          <option value="all">All transactions</option>
          <option value="expense">Expenses</option>
          <option value="income">Income</option>
        </select>
      </div>

      {transactions.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><ArrowDownLeft size={23} /></div>
          <strong>No transactions found</strong>
          <p>Add your first income or expense to see it here.</p>
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>TRANSACTION</th><th>CATEGORY</th><th>DATE</th><th>AMOUNT</th><th aria-label="Actions" /></tr></thead>
            <tbody>
              {transactions.map((item) => {
                const isIncome = item.type === 'income';
                const Icon = isIncome ? ArrowDownLeft : ArrowUpRight;
                return (
                  <tr key={item.id}>
                    <td>
                      <div className="transaction-name">
                        <span className={`transaction-icon ${isIncome ? 'income-tone' : 'expense-tone'}`}><Icon size={17} /></span>
                        <strong>{item.title}</strong>
                      </div>
                    </td>
                    <td><span className="category-pill">{item.category}</span></td>
                    <td className="muted-cell">{formatDate(item.date)}</td>
                    <td className={isIncome ? 'amount-income' : 'amount-expense'}>
                      {isIncome ? '+' : '−'}{formatCurrency(item.amount)}
                    </td>
                    <td>
                      <button className="delete-button" type="button" aria-label={`Delete ${item.title}`} onClick={() => onDelete(item.id)}>
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
