import { Target } from 'lucide-react';

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
}

export default function BudgetCard({ budget, expenses, onBudgetChange }) {
  const percentage = budget > 0 ? Math.min((expenses / budget) * 100, 100) : 0;
  const remaining = budget - expenses;

  return (
    <section className="panel budget-panel">
      <div className="section-heading">
        <div><p className="eyebrow">MONTHLY PLAN</p><h2>Monthly budget</h2></div>
        <span className="budget-icon"><Target size={19} /></span>
      </div>
      <label className="budget-input-label">
        Set your spending limit
        <div className="budget-input-wrap">
          <span>₹</span>
          <input type="number" min="0" value={budget} onChange={(e) => onBudgetChange(Math.max(0, Number(e.target.value)))} />
        </div>
      </label>
      <div className="budget-progress-info">
        <span>{formatCurrency(expenses)} spent</span>
        <strong>{Math.round(percentage)}%</strong>
      </div>
      <div className="progress-track"><div className={`progress-fill ${percentage >= 100 ? 'over-budget' : ''}`} style={{ width: `${percentage}%` }} /></div>
      <p className={`budget-remaining ${remaining < 0 ? 'over-text' : ''}`}>
        {remaining >= 0 ? `${formatCurrency(remaining)} remaining` : `${formatCurrency(Math.abs(remaining))} over budget`}
      </p>
    </section>
  );
}
