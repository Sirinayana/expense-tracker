import { Bell, Search } from 'lucide-react';

export default function Header({ activePage, search, onSearch }) {
  return (
    <header className="topbar">
      <div>
        <p className="eyebrow">YOUR FINANCES AT A GLANCE</p>
        <h1>{activePage}</h1>
      </div>
      <div className="topbar-actions">
        <label className="global-search">
          <Search size={17} />
          <input
            aria-label="Search transactions"
            placeholder="Search transactions..."
            value={search}
            onChange={(event) => onSearch(event.target.value)}
          />
        </label>
        <button className="icon-button" type="button" aria-label="Notifications">
          <Bell size={19} />
          <span className="notification-dot" />
        </button>
        <div className="avatar top-avatar">SP</div>
      </div>
    </header>
  );
}
