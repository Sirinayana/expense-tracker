import { LayoutDashboard, ReceiptText, Wallet, ChartNoAxesCombined } from 'lucide-react';

const items = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Transactions', icon: ReceiptText },
  { label: 'Budgets', icon: Wallet },
  { label: 'Reports', icon: ChartNoAxesCombined },
];

export default function Sidebar({ activePage, onNavigate }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-mark"><Wallet size={21} /></span>
        <span>Expense<span className="brand-light">Flow</span></span>
      </div>

      <p className="nav-heading">WORKSPACE</p>
      <nav className="side-nav" aria-label="Main navigation">
        {items.map(({ label, icon: Icon }) => (
          <button
            className={`nav-item ${activePage === label ? 'active' : ''}`}
            key={label}
            onClick={() => onNavigate(label)}
            type="button"
          >
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <div className="help-card">
          <div className="help-icon">?</div>
          <strong>Need a hand?</strong>
          <p>Keep your finances organized, one transaction at a time.</p>
        </div>
        <div className="profile">
          <div className="avatar">SP</div>
          <div><strong>My Account</strong><span>Personal workspace</span></div>
        </div>
      </div>
    </aside>
  );
}
