import { useState } from 'react';
import { Plus } from 'lucide-react';

const today = new Date().toISOString().slice(0, 10);

export default function ExpenseForm({ onAddTransaction }) {
  const [type, setType] = useState('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [date, setDate] = useState(today);
  const [error, setError] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const numericAmount = Number(amount);

    if (!title.trim()) {
      setError('Please enter a transaction name.');
      return;
    }
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      setError('Please enter an amount greater than zero.');
      return;
    }

    onAddTransaction({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      title: title.trim(),
      amount: numericAmount,
      category,
      date,
      type,
    });

    setTitle('');
    setAmount('');
    setCategory('Food');
    setDate(today);
    setError('');
  }

  return (
    <section className="panel form-panel">
      <div className="section-heading">
        <div><p className="eyebrow">QUICK ENTRY</p><h2>Add a transaction</h2></div>
      </div>

      <div className="type-switch" role="group" aria-label="Transaction type">
        <button type="button" className={type === 'expense' ? 'selected expense-selected' : ''} onClick={() => setType('expense')}>Expense</button>
        <button type="button" className={type === 'income' ? 'selected income-selected' : ''} onClick={() => setType('income')}>Income</button>
      </div>

      <form className="transaction-form" onSubmit={handleSubmit}>
        <label>
          Description
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Grocery shopping" />
        </label>
        <label>
          Amount (₹)
          <input type="number" min="0.01" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="e.g. 850" />
        </label>
        <label>
          Category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {(type === 'expense'
              ? ['Food', 'Travel', 'Shopping', 'Bills', 'Health', 'Education', 'Entertainment', 'Other']
              : ['Salary', 'Freelance', 'Business', 'Gift', 'Other']
            ).map((item) => <option key={item}>{item}</option>)}
          </select>
        </label>
        <label>
          Date
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </label>
        <button className="primary-button add-button" type="submit"><Plus size={17} /> Add {type}</button>
      </form>
      {error && <p className="form-error" role="alert">{error}</p>}
    </section>
  );
}
