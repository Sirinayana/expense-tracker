import { ArrowDownLeft, ArrowUpRight, WalletCards } from 'lucide-react';

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
}

export default function SummaryCards({ income, expenses, balance }) {
  const cards = [
    { label: 'Total Income', value: income, icon: ArrowDownLeft, tone: 'green', note: 'Money received' },
    { label: 'Total Expenses', value: expenses, icon: ArrowUpRight, tone: 'orange', note: 'Money spent' },
    { label: 'Available Balance', value: balance, icon: WalletCards, tone: 'purple', note: 'Income minus expenses' },
  ];

  return (
    <section className="summary-grid" aria-label="Financial summary">
      {cards.map(({ label, value, icon: Icon, tone, note }) => (
        <article className="summary-card" key={label}>
          <div className="summary-card-top">
            <span>{label}</span>
            <span className={`summary-icon ${tone}`}><Icon size={19} /></span>
          </div>
          <strong className="summary-value">{formatCurrency(value)}</strong>
          <span className="summary-note">{note}</span>
        </article>
      ))}
    </section>
  );
}
