const COLORS = ['#6c63ff', '#25b88a', '#f4a340', '#e879a5', '#4e9bd8', '#9b8af5', '#8b98a9', '#d18c58'];

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
}

export default function ExpenseChart({ transactions }) {
  const totals = transactions
    .filter((item) => item.type === 'expense')
    .reduce((result, item) => {
      result[item.category] = (result[item.category] || 0) + item.amount;
      return result;
    }, {});

  const entries = Object.entries(totals).sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((sum, [, amount]) => sum + amount, 0);

  return (
    <section className="panel chart-panel">
      <div className="section-heading"><div><p className="eyebrow">WHERE IT GOES</p><h2>Spending by category</h2></div></div>
      {entries.length === 0 ? (
        <div className="chart-empty">Your category breakdown will appear after you add expenses.</div>
      ) : (
        <div className="category-chart">
          <div className="donut-wrap">
            <div className="donut" style={{ background: `conic-gradient(${entries.map(([category, amount], index) => {
              const start = entries.slice(0, index).reduce((sum, entry) => sum + entry[1], 0) / total * 100;
              const end = start + amount / total * 100;
              return `${COLORS[index % COLORS.length]} ${start}% ${end}%`;
            }).join(', ')})` }}>
              <div className="donut-hole"><strong>{formatCurrency(total)}</strong><span>Total spent</span></div>
            </div>
          </div>
          <div className="legend-list">
            {entries.map(([category, amount], index) => (
              <div className="legend-row" key={category}>
                <span className="legend-dot" style={{ background: COLORS[index % COLORS.length] }} />
                <span className="legend-category">{category}</span>
                <strong>{Math.round(amount / total * 100)}%</strong>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
