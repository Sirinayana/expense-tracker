import { useEffect, useMemo, useState } from 'react';
import Sidebar from '../components/Sidebar.jsx';
import Header from '../components/Header.jsx';
import SummaryCards from '../components/SummaryCards.jsx';
import ExpenseForm from '../components/ExpenseForm.jsx';
import TransactionList from '../components/TransactionList.jsx';
import BudgetCard from '../components/BudgetCard.jsx';
import ExpenseChart from '../components/ExpenseChart.jsx';

const STORAGE_KEY = 'expenseflow-transactions';
const BUDGET_KEY = 'expenseflow-monthly-budget';

function readTransactions() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export default function Dashboard() {
  const [transactions, setTransactions] = useState(readTransactions);
  const [budget, setBudget] = useState(() => {
    const saved = localStorage.getItem(BUDGET_KEY);
    return saved === null ? 20000 : Number(saved);
  });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [activePage, setActivePage] = useState('Dashboard');

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(BUDGET_KEY, String(budget));
  }, [budget]);

  const income = transactions
    .filter((item) => item.type === 'income')
    .reduce((sum, item) => sum + item.amount, 0);

  const expenses = transactions
    .filter((item) => item.type === 'expense')
    .reduce((sum, item) => sum + item.amount, 0);

  const balance = income - expenses;

  const visibleTransactions = useMemo(() => {
    return transactions
      .filter((item) => filter === 'all' || item.type === filter)
      .filter((item) => item.title.toLowerCase().includes(search.toLowerCase()) ||
        item.category.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [transactions, filter, search]);

  function addTransaction(transaction) {
    setTransactions((current) => [transaction, ...current]);
  }

  function deleteTransaction(id) {
    setTransactions((current) => current.filter((item) => item.id !== id));
  }

  return (
    <div className="app-layout">
      <Sidebar activePage={activePage} onNavigate={setActivePage} />

      <main className="main-content">
        <Header activePage={activePage} search={search} onSearch={setSearch} />

        {activePage === 'Dashboard' ? (
          <>
            <SummaryCards income={income} expenses={expenses} balance={balance} />
            <div className="dashboard-grid">
              <div className="dashboard-main-column">
                <ExpenseForm onAddTransaction={addTransaction} />
                <TransactionList
                  transactions={visibleTransactions}
                  onDelete={deleteTransaction}
                  filter={filter}
                  onFilterChange={setFilter}
                />
              </div>
              <div className="dashboard-side-column">
                <BudgetCard budget={budget} expenses={expenses} onBudgetChange={setBudget} />
                <ExpenseChart transactions={transactions} />
              </div>
            </div>
          </>
        ) : (
          <section className="panel page-placeholder">
            <p className="eyebrow">WORKSPACE</p>
            <h2>{activePage}</h2>
            <p>This section is ready for future expansion. Your dashboard already supports transaction search, filtering, budgets and category analytics.</p>
            <button className="secondary-button" onClick={() => setActivePage('Dashboard')}>Back to dashboard</button>
          </section>
        )}
      </main>
    </div>
  );
}
